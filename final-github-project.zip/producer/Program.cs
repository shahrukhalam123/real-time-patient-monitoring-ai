
using Confluent.Kafka;
using System.Text.Json;

var config = new ProducerConfig
{
    BootstrapServers = "<BOOTSTRAP_SERVER>",
    SecurityProtocol = SecurityProtocol.SaslSsl,
    SaslMechanism = SaslMechanism.Plain,
    SaslUsername = "<API_KEY>",
    SaslPassword = "<API_SECRET>"
};

var producer = new ProducerBuilder<Null,string>(config).Build();
var random = new Random();

while(true){
    var data = new {
        patientId = "P1",
        heartRate = random.Next(50,140),
        spo2 = random.Next(85,100),
        timestamp = DateTime.UtcNow
    };

    await producer.ProduceAsync("patient-vitals", new Message<Null,string>{Value = JsonSerializer.Serialize(data)});
    Console.WriteLine("Produced data");
    await Task.Delay(2000);
}
