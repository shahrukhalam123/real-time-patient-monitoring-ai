# Patient Monitoring System (Kafka + AI + Notifications)

## Features
- Kafka (Confluent Cloud)
- Real-time processing
- AI insights (risk, trend, summary)
- PDF reports
- Telegram + WhatsApp alerts

## Services
- producer
- processor
- ai-service
- notifier

## Run

dotnet run --project producer

dotnet run --project processor

dotnet run --project ai-service

dotnet run --project notifier
