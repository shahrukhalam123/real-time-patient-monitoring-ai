
using Confluent.Kafka;

var config = new ConsumerConfig{
    BootstrapServers = "<BOOTSTRAP_SERVER>",
    SecurityProtocol = SecurityProtocol.SaslSsl,
    SaslMechanism = SaslMechanism.Plain,
    SaslUsername = "<API_KEY>",
    SaslPassword = "<API_SECRET>",
    GroupId = "ai-service",
    AutoOffsetReset = AutoOffsetReset.Earliest
};

var consumer = new ConsumerBuilder<Ignore,string>(config).Build();
consumer.Subscribe("patient-ai-output");

while(true){
    var msg = consumer.Consume();
    Console.WriteLine("AI Processing: " + msg.Message.Value);
}
