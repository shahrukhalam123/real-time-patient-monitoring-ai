
using Confluent.Kafka;
using System.Text.Json;

var config = new ConsumerConfig{
    BootstrapServers = "<BOOTSTRAP_SERVER>",
    SecurityProtocol = SecurityProtocol.SaslSsl,
    SaslMechanism = SaslMechanism.Plain,
    SaslUsername = "<API_KEY>",
    SaslPassword = "<API_SECRET>",
    GroupId = "processor",
    AutoOffsetReset = AutoOffsetReset.Earliest
};

var consumer = new ConsumerBuilder<Ignore,string>(config).Build();
consumer.Subscribe("patient-vitals");

var producer = new ProducerBuilder<Null,string>(config).Build();

while(true){
    var msg = consumer.Consume();
    await producer.ProduceAsync("patient-ai-output", new Message<Null,string>{Value = msg.Message.Value});
}
